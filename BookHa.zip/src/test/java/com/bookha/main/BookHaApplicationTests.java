package com.bookha.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookHaApplicationTests {

	@Test
	void contextLoads() {
	}

}
