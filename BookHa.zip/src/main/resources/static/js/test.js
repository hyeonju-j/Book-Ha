/**
 *  mvc test
 */

$(function(){
	
	$('#btn').click(function(){
		alert("ok");
	})
	
})